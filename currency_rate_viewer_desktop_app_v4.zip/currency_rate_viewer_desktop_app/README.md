# Currency Rate Viewer (Desktop) v3

Tkinter desktop app: convert between 15 currencies with live rates, compare one amount against all
currencies, browse and export history, see real daily rate history, set rate alerts, and view usage analytics.
Works with no internet.

## Run
```
python main.py                                   # Python 3.9+, no third-party packages
python -m unittest discover -s tests -t . -v     # 60 automated tests
./build_exe.sh                                   # optional single-file executable (PyInstaller)
```

## Features
| Tab | What it does |
|---|---|
| Converter | Validated amount, swap, Enter-to-convert, "Refresh rate", favourite pairs (star), colour-coded source |
| Compare | One amount -> all supported currencies from a single rate fetch |
| History | SQLite-backed, live search, delete selected / clear all, **Export CSV** |
| Trends | Line chart of a pair's rates. **Load 30-day history** downloads daily data (idempotent); every live fetch also adds a point |
| Alerts | "Notify me when USD/INR is above/below X". Checked on every live fetch and via **Check now**; one-shot with re-arm; never fires on offline estimates |
| Analytics | Totals, most-used pair, live-rate share, per-pair avg/min/max, usage bar chart |

Also: light/dark theme, remembered last pair & favourites, rotating log file (`data/app.log`),
background threads (UI never freezes), money handled with `Decimal`.

**Rate resolution chain:** fresh cache -> live API (HTTPS, 5 s timeout) -> stale cache -> offline estimate.
Every record stores its source (Live / Cached / Cached (stale) / Offline estimate).

## Structure
See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md). Short version: `ui` -> `service` -> (`rate_service`, `repository`),
with pure helpers (`validators`, `analytics`, `charts`, `presenter`, `settings`) and one composition root (`main.py`).

## Testing
60 tests: validation, rate chain (live/cache/stale/offline/corrupt cache), SQLite repository (incl. SQL-injection
and persistence), snapshots + throttling, historical-data parsing and backfill, alert rules and lifecycle, compare, analytics, settings sanitising, chart geometry, presenter, and a
UI smoke test that drives every window handler against a stub toolkit (runs headless). CI runs on Linux + Windows.

## Security & robustness
Input whitelist/range validation, parameterised SQL, HTTPS only, atomic file writes, specific exception types
(no bare `except:`), corrupt cache/settings never crash the app, no secrets or credentials anywhere.

## Configuration
Data folder: `data/` (override with env var `CRV_DATA_DIR`). Currencies, cache TTL, timeout: `currency_viewer/config.py`.

## Notes on external services
- Live rates: open.er-api.com (no key). Historical rates: Frankfurter (ECB reference data, no key); it does not
  cover every currency (e.g. AED) - the app then shows a clear "not available" message instead of failing.
- Both endpoints are configurable in `currency_viewer/config.py` and are injected, so tests never touch the network.
