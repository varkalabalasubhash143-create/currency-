"""Pure chart geometry. The UI only draws what these functions return."""

from decimal import Decimal
from typing import List, Sequence, Tuple


def line_points(values: Sequence[Decimal], width: float, height: float,
                pad: float = 34) -> List[Tuple[float, float]]:
    """Map a series to canvas coordinates (y grows downward). Flat series sit mid-height."""
    n = len(values)
    if n == 0:
        return []
    lo, hi = min(values), max(values)
    inner_w, inner_h = width - 2 * pad, height - 2 * pad
    pts = []
    for i, v in enumerate(values):
        x = width / 2 if n == 1 else pad + inner_w * i / (n - 1)
        frac = Decimal("0.5") if hi == lo else (v - lo) / (hi - lo)
        pts.append((x, height - pad - float(frac) * inner_h))
    return pts


def bar_boxes(counts: Sequence[int], width: float, height: float,
              pad: float = 30, gap: float = 0.3) -> List[Tuple[float, float, float, float]]:
    """Return (x0, y0, x1, y1) for each bar; the tallest bar fills the plot height."""
    if not counts or max(counts) <= 0:
        return []
    slot = (width - 2 * pad) / len(counts)
    peak = max(counts)
    boxes = []
    for i, c in enumerate(counts):
        x0 = pad + i * slot + slot * gap / 2
        x1 = pad + (i + 1) * slot - slot * gap / 2
        top = height - pad - (height - 2 * pad) * c / peak
        boxes.append((x0, top, x1, height - pad))
    return boxes
