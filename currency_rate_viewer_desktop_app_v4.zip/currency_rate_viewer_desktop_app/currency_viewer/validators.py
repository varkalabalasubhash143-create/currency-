"""Input validation. Pure functions, easy to unit test."""

from decimal import Decimal, InvalidOperation

from .config import CURRENCIES, MAX_AMOUNT
from .errors import ValidationError


def validate_currency(code: str, label: str = "Currency") -> str:
    code = (code or "").strip().upper()
    if not code:
        raise ValidationError(f"{label} is required.")
    if code not in CURRENCIES:
        raise ValidationError(f"{label} '{code}' is not supported.")
    return code


def validate_amount(text: str, label: str = "Amount") -> Decimal:
    raw = (text or "").strip().replace(",", "")
    if not raw:
        raise ValidationError(f"{label} is required.")
    try:
        value = Decimal(raw)
    except InvalidOperation:
        raise ValidationError(f"{label} must be a number, e.g. 250 or 99.95.") from None
    if not value.is_finite():
        raise ValidationError(f"{label} must be a finite number.")
    if value <= 0:
        raise ValidationError(f"{label} must be greater than zero.")
    if value > MAX_AMOUNT:
        raise ValidationError(f"{label} must not exceed {MAX_AMOUNT:,}.")
    return value
