"""Plain data objects shared between layers (no I/O, no UI)."""

from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from typing import Dict, Optional

SOURCE_LIVE = "Live"
SOURCE_CACHED = "Cached"
SOURCE_STALE = "Cached (stale)"
SOURCE_OFFLINE = "Offline estimate"


@dataclass(frozen=True)
class RateQuote:
    base: str
    rates: Dict[str, Decimal]
    source: str
    fetched_at: datetime


@dataclass(frozen=True)
class ConversionRecord:
    base: str
    target: str
    amount: Decimal
    rate: Decimal
    result: Decimal
    source: str
    created_at: datetime
    id: Optional[int] = None

    @property
    def pair(self) -> str:
        return f"{self.base}/{self.target}"


@dataclass(frozen=True)
class CompareRow:
    code: str
    name: str
    rate: Decimal
    converted: Decimal


@dataclass(frozen=True)
class Alert:
    base: str
    target: str
    direction: str            # "above" or "below"
    threshold: Decimal
    created_at: datetime
    id: Optional[int] = None
    triggered_at: Optional[datetime] = None
    triggered_rate: Optional[Decimal] = None

    @property
    def pair(self) -> str:
        return f"{self.base}/{self.target}"

    @property
    def active(self) -> bool:
        return self.triggered_at is None
