"""Currency Rate Viewer - a layered desktop application."""

import logging

__version__ = "4.0.0"
logging.getLogger(__name__).addHandler(logging.NullHandler())  # library-safe default
