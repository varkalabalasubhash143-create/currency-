"""Application-specific exceptions so callers never catch bare Exception."""


class CurrencyViewerError(Exception):
    """Base class for all expected application errors."""


class ValidationError(CurrencyViewerError):
    """User input failed validation. The message is safe to show to the user."""


class RateFetchError(CurrencyViewerError):
    """A live rate request failed (network, bad payload, API error)."""


class StorageError(CurrencyViewerError):
    """Reading or writing persistent data failed."""
