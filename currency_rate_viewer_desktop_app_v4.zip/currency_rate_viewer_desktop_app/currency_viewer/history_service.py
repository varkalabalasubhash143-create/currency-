"""Historical daily rates for the trend chart (network call is injectable)."""

import json
import logging
import urllib.error
import urllib.request
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from typing import Callable, List, Tuple

from . import config
from .errors import RateFetchError

log = logging.getLogger(__name__)
Point = Tuple[datetime, Decimal]
HistoryFetcher = Callable[[str, str, date, date], List[Point]]


def parse_series(payload: dict, target: str) -> List[Point]:
    """Turn {"rates": {"2026-01-02": {"INR": 83.1}, ...}} into sorted (datetime, Decimal) points."""
    rates = payload.get("rates") if isinstance(payload, dict) else None
    if not isinstance(rates, dict) or not rates:
        raise RateFetchError("No historical data returned for this pair.")
    points: List[Point] = []
    for day, row in rates.items():
        try:
            value = Decimal(str(row[target]))
            when = datetime.combine(date.fromisoformat(day), time(12, 0))
        except (KeyError, TypeError, ValueError, InvalidOperation):
            continue  # skip malformed rows rather than failing the whole import
        if value > 0:
            points.append((when, value))
    if not points:
        raise RateFetchError(f"History source has no usable data for {target}.")
    return sorted(points)


def http_history_fetcher(base: str, target: str, start: date, end: date) -> List[Point]:
    url = config.HISTORY_API_URL.format(start=start.isoformat(), end=end.isoformat(),
                                        base=base, target=target)
    try:
        with urllib.request.urlopen(url, timeout=config.API_TIMEOUT_SECONDS * 2) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code in (404, 422):
            raise RateFetchError(f"Historical data is not available for {base}/{target}.") from exc
        raise RateFetchError(f"History service error ({exc.code}).") from exc
    except (urllib.error.URLError, OSError, ValueError) as exc:
        log.warning("History fetch failed: %s", exc)
        raise RateFetchError("Could not reach the history service. Check your connection.") from exc
    return parse_series(payload, target)
