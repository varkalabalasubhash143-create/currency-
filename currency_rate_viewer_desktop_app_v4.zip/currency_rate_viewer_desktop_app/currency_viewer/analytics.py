"""Pure analytics over conversion history (no I/O)."""

from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from typing import Dict, List, Sequence

from .models import SOURCE_LIVE, ConversionRecord


@dataclass(frozen=True)
class PairStats:
    pair: str
    count: int
    avg_rate: Decimal
    min_rate: Decimal
    max_rate: Decimal
    total_converted: Decimal  # sum of `result`, in the target currency


@dataclass(frozen=True)
class Summary:
    total: int
    unique_pairs: int
    most_used_pair: str
    live_share_pct: float
    per_day: Dict[str, int]
    pairs: List[PairStats]


def summarize(records: Sequence[ConversionRecord]) -> Summary:
    if not records:
        return Summary(0, 0, "-", 0.0, {}, [])

    groups = defaultdict(list)
    for r in records:
        groups[r.pair].append(r)

    pairs = []
    for pair, rs in groups.items():
        rates = [r.rate for r in rs]
        pairs.append(PairStats(pair, len(rs), sum(rates) / len(rates), min(rates), max(rates),
                               sum((r.result for r in rs), Decimal(0))))
    pairs.sort(key=lambda p: (-p.count, p.pair))

    per_day = Counter(r.created_at.strftime("%Y-%m-%d") for r in records)
    live = sum(1 for r in records if r.source == SOURCE_LIVE)
    return Summary(
        total=len(records),
        unique_pairs=len(pairs),
        most_used_pair=pairs[0].pair,
        live_share_pct=round(100 * live / len(records), 1),
        per_day=dict(sorted(per_day.items())),
        pairs=pairs,
    )
