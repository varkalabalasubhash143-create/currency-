"""Exchange-rate acquisition: fresh cache -> live API -> stale cache -> offline table.

The network call is injected (`fetcher`) so the logic is fully testable offline.
"""

import json
import logging
import time
import urllib.error
import urllib.request
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Callable, Dict

from . import config
from .errors import RateFetchError
from .models import (SOURCE_CACHED, SOURCE_LIVE, SOURCE_OFFLINE, SOURCE_STALE,
                     RateQuote)

log = logging.getLogger(__name__)

Fetcher = Callable[[str], Dict[str, float]]


def http_fetcher(base: str) -> Dict[str, float]:
    """Fetch rates for `base` from the public API over HTTPS."""
    url = config.API_URL.format(base=base)
    try:
        with urllib.request.urlopen(url, timeout=config.API_TIMEOUT_SECONDS) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
        if payload.get("result") != "success":
            raise RateFetchError("API reported a failure.")
        rates = payload["rates"]
        if not isinstance(rates, dict) or not rates:
            raise RateFetchError("API returned no rates.")
        return rates
    except (urllib.error.URLError, OSError, ValueError, KeyError) as exc:
        raise RateFetchError(f"Live rates unavailable: {exc}") from exc


class RateService:
    def __init__(self, cache_path: Path = config.CACHE_FILE,
                 fetcher: Fetcher = http_fetcher,
                 ttl_seconds: int = config.CACHE_TTL_SECONDS,
                 clock: Callable[[], float] = time.time):
        self._cache_path = Path(cache_path)
        self._fetch = fetcher
        self._ttl = ttl_seconds
        self._clock = clock

    # -- public ------------------------------------------------------------
    def get_quote(self, base: str, force_refresh: bool = False) -> RateQuote:
        cache = self._read_cache()
        entry = cache.get(base)

        if entry and not force_refresh and self._age(entry) <= self._ttl:
            return self._to_quote(base, entry, SOURCE_CACHED)

        try:
            raw = self._fetch(base)
            entry = {"fetched": self._clock(), "rates": {k: str(v) for k, v in raw.items()}}
            cache[base] = entry
            self._write_cache(cache)
            return self._to_quote(base, entry, SOURCE_LIVE)
        except RateFetchError as exc:
            log.warning("Live rates for %s failed (%s); falling back", base, exc)
            if entry:
                return self._to_quote(base, entry, SOURCE_STALE)
            return self._offline_quote(base)

    # -- internals ---------------------------------------------------------
    def _age(self, entry: dict) -> float:
        return self._clock() - float(entry.get("fetched", 0))

    @staticmethod
    def _to_quote(base: str, entry: dict, source: str) -> RateQuote:
        rates = {k: Decimal(v) for k, v in entry["rates"].items()}
        return RateQuote(base, rates, source,
                         datetime.fromtimestamp(float(entry["fetched"])))

    @staticmethod
    def _offline_quote(base: str) -> RateQuote:
        table = config.OFFLINE_USD_RATES
        base_rate = Decimal(str(table[base]))
        rates = {code: Decimal(str(r)) / base_rate for code, r in table.items()}
        return RateQuote(base, rates, SOURCE_OFFLINE, datetime.now())

    def _read_cache(self) -> dict:
        try:
            data = json.loads(self._cache_path.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
        except (OSError, ValueError):
            return {}  # missing/corrupt cache is not fatal; it is rebuilt

    def _write_cache(self, cache: dict) -> None:
        try:
            self._cache_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._cache_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(cache), encoding="utf-8")
            tmp.replace(self._cache_path)  # atomic swap
        except OSError:
            pass  # cache is an optimisation only
