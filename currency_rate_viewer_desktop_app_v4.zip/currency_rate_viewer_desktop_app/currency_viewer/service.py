"""Application service: orchestrates validation, rates, maths and persistence.

The UI talks only to this class, never to SQLite or the network directly.
"""

import logging
import threading
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal
from pathlib import Path
from typing import List, Optional, Tuple

from . import alerts as alert_rules
from . import analytics
from .config import (CURRENCIES, HISTORY_DEFAULT_DAYS, HISTORY_MAX_DAYS, MAX_ALERTS)
from .errors import StorageError, ValidationError
from .history_service import HistoryFetcher, http_history_fetcher
from .models import (SOURCE_CACHED, SOURCE_LIVE, Alert, CompareRow, ConversionRecord,
                     RateQuote)
from .rate_service import RateService
from .repository import ConversionRepository
from .validators import validate_amount, validate_currency

log = logging.getLogger(__name__)

_CENT = Decimal("0.01")
_RATE_PLACES = Decimal("0.000001")


class ConverterService:
    def __init__(self, rates: RateService, repo: ConversionRepository,
                 history_fetcher: HistoryFetcher = http_history_fetcher):
        self._rates = rates
        self._repo = repo
        self._history_fetcher = history_fetcher
        self._notes: List[str] = []
        self._notes_lock = threading.Lock()

    @staticmethod
    def currencies() -> List[str]:
        return list(CURRENCIES)

    def convert(self, base: str, target: str, amount_text: str,
                force_refresh: bool = False) -> ConversionRecord:
        base = validate_currency(base, "'From' currency")
        target = validate_currency(target, "'To' currency")
        amount = validate_amount(amount_text)

        quote: RateQuote = self._rates.get_quote(base, force_refresh)
        self._remember(quote)
        if target not in quote.rates:
            raise ValidationError(f"No rate available for {base} -> {target}.")

        rate = quote.rates[target]
        result = (amount * rate).quantize(_CENT, rounding=ROUND_HALF_UP)
        record = ConversionRecord(base, target, amount,
                                  rate.quantize(_RATE_PLACES, rounding=ROUND_HALF_UP),
                                  result, quote.source, datetime.now())
        return self._repo.add(record)

    def compare(self, base: str, amount_text: str,
                force_refresh: bool = False) -> Tuple[RateQuote, List[CompareRow]]:
        """Convert one amount into every supported currency using a single rate fetch."""
        base = validate_currency(base, "'From' currency")
        amount = validate_amount(amount_text)
        quote = self._rates.get_quote(base, force_refresh)
        self._remember(quote)
        rows = [CompareRow(code, CURRENCIES[code], quote.rates[code].quantize(_RATE_PLACES),
                           (amount * quote.rates[code]).quantize(_CENT, rounding=ROUND_HALF_UP))
                for code in sorted(CURRENCIES) if code != base and code in quote.rates]
        return quote, rows

    def rate_history(self, base: str, target: str, limit: int = 100):
        base = validate_currency(base, "'From' currency")
        target = validate_currency(target, "'To' currency")
        return self._repo.snapshot_series(base, target, limit)

    def _remember(self, quote: RateQuote) -> None:
        """Side effects of a fresh quote: keep a trend snapshot and evaluate alerts.
        Failures here are logged and must never break the user's conversion."""
        try:
            self._snapshot(quote)
            fired = self._evaluate_alerts(quote)
            if fired:
                with self._notes_lock:
                    self._notes.extend(fired)
        except StorageError as exc:
            log.warning("Quote side effects skipped: %s", exc)

    def _snapshot(self, quote: RateQuote) -> None:
        if quote.source == SOURCE_LIVE:
            wanted = {c: r for c, r in quote.rates.items() if c in CURRENCIES}
            self._repo.add_snapshots(quote.fetched_at, quote.base, wanted)

    # -- alerts ------------------------------------------------------------
    def add_alert(self, base: str, target: str, direction: str, threshold_text: str) -> Alert:
        base = validate_currency(base, "'From' currency")
        target = validate_currency(target, "'To' currency")
        if base == target:
            raise ValidationError("Choose two different currencies for an alert.")
        direction = alert_rules.validate_direction(direction)
        threshold = validate_amount(threshold_text, "Target rate")
        if len(self._repo.list_alerts()) >= MAX_ALERTS:
            raise ValidationError(f"You can keep at most {MAX_ALERTS} alerts. Delete some first.")
        return self._repo.add_alert(Alert(base, target, direction, threshold, datetime.now()))

    def list_alerts(self) -> List[Alert]:
        return self._repo.list_alerts()

    def delete_alerts(self, ids) -> int:
        return self._repo.delete_alerts(ids)

    def rearm_alert(self, alert_id: int) -> None:
        self._repo.rearm_alert(alert_id)

    def check_alerts(self, force_refresh: bool = True) -> List[str]:
        """Fetch fresh rates for every base that has an active alert and fire any that match."""
        fired: List[str] = []
        for base in sorted({a.base for a in self._repo.list_alerts(active_only=True)}):
            quote = self._rates.get_quote(base, force_refresh)
            try:
                self._snapshot(quote)
            except StorageError as exc:
                log.warning("Snapshot skipped: %s", exc)
            fired += self._evaluate_alerts(quote)
        return fired

    def _evaluate_alerts(self, quote: RateQuote) -> List[str]:
        """Only trustworthy (live or fresh-cached) rates may trigger alerts - never estimates."""
        if quote.source not in (SOURCE_LIVE, SOURCE_CACHED):
            return []
        fired = []
        for a in self._repo.list_alerts(active_only=True):
            if a.base != quote.base or a.target not in quote.rates:
                continue
            rate = quote.rates[a.target]
            if alert_rules.is_triggered(a.direction, a.threshold, rate):
                self._repo.mark_triggered(a.id, datetime.now(), rate)
                fired.append(alert_rules.message(a, rate))
        return fired

    def take_notifications(self) -> List[str]:
        """Alert messages raised as a side effect of other actions; returned once."""
        with self._notes_lock:
            notes, self._notes = self._notes, []
        return notes

    # -- historical rates ----------------------------------------------------
    def backfill_history(self, base: str, target: str, days: int = HISTORY_DEFAULT_DAYS) -> int:
        """Download daily history for a pair into the trend store. Returns new points added."""
        base = validate_currency(base, "'From' currency")
        target = validate_currency(target, "'To' currency")
        if base == target:
            raise ValidationError("Choose two different currencies.")
        if not 1 <= int(days) <= HISTORY_MAX_DAYS:
            raise ValidationError(f"Days must be between 1 and {HISTORY_MAX_DAYS}.")
        end = date.today()
        points = self._history_fetcher(base, target, end - timedelta(days=int(days)), end)
        return self._repo.add_series(base, target, points)

    def history(self, search: Optional[str] = None) -> List[ConversionRecord]:
        return self._repo.list(search)

    def delete(self, ids) -> int:
        return self._repo.delete(ids)

    def clear_history(self) -> None:
        self._repo.clear()

    def export_history(self, path: Path, search: Optional[str] = None) -> int:
        return self._repo.export_csv(path, self._repo.list(search))

    def analytics(self) -> analytics.Summary:
        return analytics.summarize(self._repo.list())
