"""Central configuration. Every tunable lives here, nowhere else."""

import os
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.environ.get("CRV_DATA_DIR", PROJECT_DIR / "data"))
DB_FILE = DATA_DIR / "conversions.db"
CACHE_FILE = DATA_DIR / "rate_cache.json"
SETTINGS_FILE = DATA_DIR / "settings.json"

API_URL = "https://open.er-api.com/v6/latest/{base}"
API_TIMEOUT_SECONDS = 5
CACHE_TTL_SECONDS = 3600

MAX_AMOUNT = 10**12  # sanity ceiling for a single conversion

# code -> display name
CURRENCIES = {
    "USD": "US Dollar", "INR": "Indian Rupee", "EUR": "Euro",
    "GBP": "British Pound", "JPY": "Japanese Yen", "AED": "UAE Dirham",
    "CAD": "Canadian Dollar", "AUD": "Australian Dollar",
    "CHF": "Swiss Franc", "CNY": "Chinese Yuan", "SGD": "Singapore Dollar",
    "NZD": "New Zealand Dollar", "HKD": "Hong Kong Dollar",
    "SEK": "Swedish Krona", "KRW": "South Korean Won",
}

# Approximate USD-based rates, used ONLY when the network and cache are both
# unavailable. Results are labelled "Offline estimate" in the UI and history.
OFFLINE_USD_RATES = {
    "USD": 1.0, "INR": 83.0, "EUR": 0.92, "GBP": 0.79, "JPY": 150.0,
    "AED": 3.6725, "CAD": 1.36, "AUD": 1.52, "CHF": 0.88, "CNY": 7.2,
    "SGD": 1.34, "NZD": 1.65, "HKD": 7.8, "SEK": 10.5, "KRW": 1330.0,
}

# Historical daily rates (ECB reference data via Frankfurter). Not every currency
# is covered (e.g. AED); unsupported pairs produce a friendly error in the UI.
HISTORY_API_URL = "https://api.frankfurter.dev/v1/{start}..{end}?base={base}&symbols={target}"
HISTORY_DEFAULT_DAYS = 30
HISTORY_MAX_DAYS = 365
MAX_ALERTS = 50
