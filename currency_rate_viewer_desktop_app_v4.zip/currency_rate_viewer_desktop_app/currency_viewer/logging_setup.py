"""File logging so failures are diagnosable without showing stack traces to users."""

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path


def configure(data_dir: Path, level: int = logging.INFO) -> None:
    root = logging.getLogger("currency_viewer")
    if root.handlers:  # idempotent
        return
    root.setLevel(level)
    try:
        Path(data_dir).mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(Path(data_dir) / "app.log", maxBytes=200_000,
                                      backupCount=2, encoding="utf-8")
    except OSError:
        handler = logging.NullHandler()  # logging must never stop the app
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s"))
    root.addHandler(handler)
