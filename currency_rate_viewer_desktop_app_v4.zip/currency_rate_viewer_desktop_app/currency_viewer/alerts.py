"""Rate-alert rules (pure functions)."""

from decimal import Decimal

from .errors import ValidationError
from .models import Alert

DIRECTIONS = ("above", "below")


def validate_direction(direction: str) -> str:
    direction = (direction or "").strip().lower()
    if direction not in DIRECTIONS:
        raise ValidationError("Direction must be 'above' or 'below'.")
    return direction


def is_triggered(direction: str, threshold: Decimal, rate: Decimal) -> bool:
    """'above' fires when rate >= threshold; 'below' fires when rate <= threshold."""
    return rate >= threshold if direction == "above" else rate <= threshold


def message(alert: Alert, rate: Decimal) -> str:
    return (f"{alert.pair} is {rate.normalize():f}, "
            f"{alert.direction} your target of {alert.threshold.normalize():f}")
