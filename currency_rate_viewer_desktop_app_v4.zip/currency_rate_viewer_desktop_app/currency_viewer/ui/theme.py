"""Colour palettes (data only) for the light and dark themes."""

PALETTES = {
    "light": {"bg": "#f4f6f8", "panel": "#e6eaef", "field": "#ffffff", "fg": "#1f2328",
              "muted": "#6e7781", "border": "#d0d7de", "accent": "#1f6feb",
              "accent_hover": "#0b5bd3", "good": "#1a7f37", "warn": "#9a6700", "grid": "#e5e9ee"},
    "dark":  {"bg": "#161b22", "panel": "#21262d", "field": "#0d1117", "fg": "#e6edf3",
              "muted": "#8b949e", "border": "#30363d", "accent": "#388bfd",
              "accent_hover": "#58a6ff", "good": "#3fb950", "warn": "#d29922", "grid": "#21262d"},
}
