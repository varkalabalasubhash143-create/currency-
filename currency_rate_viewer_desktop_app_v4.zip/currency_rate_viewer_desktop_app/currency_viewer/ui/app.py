"""Tkinter presentation layer.

No business logic lives here: validation, maths, storage and networking are all
behind ConverterService. Anything slow runs on a worker thread and reports back
through a queue, so the window never freezes. Formatting comes from presenter.py,
geometry from charts.py, colours from theme.py.
"""

import logging
import queue
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from .. import charts
from ..errors import CurrencyViewerError
from ..service import ConverterService
from ..settings import SettingsStore
from . import presenter, theme

log = logging.getLogger(__name__)


class App(tk.Tk):
    def __init__(self, service: ConverterService, settings: SettingsStore):
        super().__init__()
        self.svc = service
        self.settings = settings
        self._queue: "queue.Queue" = queue.Queue()
        self._busy_buttons = []
        self._canvases = []
        self._summary = None
        self._series = []
        self.pal = theme.PALETTES[settings.theme]

        self.title("Currency Rate Viewer")
        self.geometry("1000x700")
        self.minsize(860, 600)
        self.style = ttk.Style(self)
        self._build()
        self._apply_theme()
        self.after(100, self._poll)
        self.refresh_history()

    # ================================================================ layout
    def _build(self):
        head = ttk.Frame(self)
        head.pack(fill="x", padx=16, pady=(12, 0))
        ttk.Label(head, text="Currency Rate Viewer", font=("Helvetica", 20, "bold")).pack(side="left")
        self.btn_theme = ttk.Button(head, text="Toggle theme", command=self.toggle_theme)
        self.btn_theme.pack(side="right")

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(expand=True, fill="both", padx=16, pady=10)
        names = ("Converter", "Compare", "History", "Trends", "Alerts", "Analytics")
        self.frames = {n: ttk.Frame(self.tabs) for n in names}
        for n in names:
            self.tabs.add(self.frames[n], text=n)
        self.tabs.bind("<<NotebookTabChanged>>", lambda e: self._on_tab())

        self._build_converter(self.frames["Converter"])
        self._build_compare(self.frames["Compare"])
        self._build_history(self.frames["History"])
        self._build_trends(self.frames["Trends"])
        self._build_alerts(self.frames["Alerts"])
        self._build_analytics(self.frames["Analytics"])

        self.status = tk.StringVar(value="Ready")
        ttk.Label(self, textvariable=self.status, anchor="w", style="Status.TLabel").pack(fill="x", side="bottom")

    def _combo(self, parent, value, width=9):
        cb = ttk.Combobox(parent, values=self.svc.currencies(), state="readonly", width=width)
        cb.set(value)
        return cb

    def _build_converter(self, tab):
        last_from, last_to = self.settings.last_pair
        box = ttk.LabelFrame(tab, text="Convert", padding=18)
        box.pack(fill="x", padx=24, pady=(24, 8))
        ttk.Label(box, text="From").grid(row=0, column=0, sticky="w")
        ttk.Label(box, text="To").grid(row=0, column=2, sticky="w")
        ttk.Label(box, text="Amount").grid(row=0, column=3, sticky="w", padx=(18, 0))
        self.cmb_from = self._combo(box, last_from)
        self.cmb_to = self._combo(box, last_to)
        self.cmb_from.grid(row=1, column=0, pady=4)
        ttk.Button(box, text="⇄", width=3, command=self._swap).grid(row=1, column=1, padx=6)
        self.cmb_to.grid(row=1, column=2, pady=4)
        self.ent_amt = ttk.Entry(box, width=18)
        self.ent_amt.grid(row=1, column=3, padx=(18, 8))
        self.ent_amt.focus_set()
        self.ent_amt.bind("<Return>", lambda e: self.convert())
        self.btn_convert = ttk.Button(box, text="Convert", style="Accent.TButton", command=self.convert)
        self.btn_convert.grid(row=1, column=4, padx=6)
        self.btn_force = ttk.Button(box, text="Refresh rate", command=lambda: self.convert(force=True))
        self.btn_force.grid(row=1, column=5)
        self._busy_buttons += [self.btn_convert, self.btn_force]
        for cb in (self.cmb_from, self.cmb_to):
            cb.bind("<<ComboboxSelected>>", lambda e: self._sync_star())

        fav = ttk.Frame(tab)
        fav.pack(fill="x", padx=24)
        self.btn_star = ttk.Button(fav, text=presenter.star(False), width=3, command=self.toggle_favourite)
        self.btn_star.pack(side="left")
        ttk.Label(fav, text="Favourite pairs:").pack(side="left", padx=(8, 4))
        self.cmb_fav = ttk.Combobox(fav, values=self.settings.favourites, state="readonly", width=12)
        self.cmb_fav.pack(side="left")
        self.cmb_fav.bind("<<ComboboxSelected>>", lambda e: self._use_favourite())
        self._sync_star()

        self.lbl_result = ttk.Label(tab, text="", style="Result.TLabel")
        self.lbl_result.pack(pady=(28, 2))
        self.lbl_detail = ttk.Label(tab, text="")
        self.lbl_detail.pack()

    def _build_compare(self, tab):
        bar = ttk.Frame(tab)
        bar.pack(fill="x", padx=16, pady=12)
        ttk.Label(bar, text="From").pack(side="left")
        self.cmp_from = self._combo(bar, self.settings.last_pair[0])
        self.cmp_from.pack(side="left", padx=6)
        ttk.Label(bar, text="Amount").pack(side="left", padx=(12, 0))
        self.cmp_amt = ttk.Entry(bar, width=16)
        self.cmp_amt.pack(side="left", padx=6)
        self.cmp_amt.insert(0, "1")
        self.cmp_amt.bind("<Return>", lambda e: self.compare())
        self.btn_compare = ttk.Button(bar, text="Compare all", style="Accent.TButton", command=self.compare)
        self.btn_compare.pack(side="left", padx=6)
        self._busy_buttons.append(self.btn_compare)
        self.lbl_cmp = ttk.Label(bar, text="")
        self.lbl_cmp.pack(side="right")

        cols = ("code", "name", "rate", "converted")
        self.cmp_tree = self._tree(tab, cols, ("Code", "Currency", "Rate", "Converted amount"), (70, 220, 130, 180))

    def _build_history(self, tab):
        bar = ttk.Frame(tab)
        bar.pack(fill="x", padx=10, pady=(10, 0))
        ttk.Label(bar, text="Search:").pack(side="left")
        self.search = tk.StringVar()
        self.search.trace_add("write", lambda *a: self.refresh_history())
        ttk.Entry(bar, textvariable=self.search, width=24).pack(side="left", padx=6)
        ttk.Button(bar, text="Export CSV", command=self.export_csv).pack(side="right")
        ttk.Button(bar, text="Clear all", command=self.clear_history).pack(side="right", padx=6)
        ttk.Button(bar, text="Delete selected", command=self.delete_selected).pack(side="right")
        cols = ("id", "date", "pair", "amount", "rate", "result", "source")
        self.tree = self._tree(tab, cols, [c.title() for c in cols], (50, 150, 90, 120, 100, 130, 120),
                               selectmode="extended")
        self.tree.bind("<Delete>", lambda e: self.delete_selected())
        self.bind("<F5>", lambda e: self.refresh_history())

    def _build_trends(self, tab):
        bar = ttk.Frame(tab)
        bar.pack(fill="x", padx=16, pady=12)
        ttk.Label(bar, text="Pair").pack(side="left")
        self.tr_from = self._combo(bar, self.settings.last_pair[0])
        self.tr_to = self._combo(bar, self.settings.last_pair[1])
        self.tr_from.pack(side="left", padx=6)
        ttk.Label(bar, text="/").pack(side="left")
        self.tr_to.pack(side="left", padx=6)
        ttk.Button(bar, text="Show trend", style="Accent.TButton", command=self.show_trend).pack(side="left", padx=6)
        self.btn_history = ttk.Button(bar, text="Load 30-day history", command=self.load_history_data)
        self.btn_history.pack(side="left", padx=6)
        self._busy_buttons.append(self.btn_history)
        self.lbl_trend = ttk.Label(bar, text="")
        self.lbl_trend.pack(side="right")
        self.trend_canvas = self._canvas(tab, 360)
        self.trend_canvas.bind("<Configure>", lambda e: self._draw_trend())
        ttk.Label(tab, text="Points come from downloaded daily history and from every live rate fetch.").pack(pady=4)

    def _build_alerts(self, tab):
        box = ttk.LabelFrame(tab, text="New alert", padding=12)
        box.pack(fill="x", padx=16, pady=(12, 4))
        self.al_from = self._combo(box, self.settings.last_pair[0])
        self.al_to = self._combo(box, self.settings.last_pair[1])
        self.al_dir = ttk.Combobox(box, values=("above", "below"), state="readonly", width=8)
        self.al_dir.set("above")
        self.al_val = ttk.Entry(box, width=14)
        self.al_val.bind("<Return>", lambda e: self.add_alert())
        for i, (label, w) in enumerate((("From", self.al_from), ("To", self.al_to),
                                        ("Notify when rate is", self.al_dir), ("Target rate", self.al_val))):
            ttk.Label(box, text=label).grid(row=0, column=i, sticky="w", padx=6)
            w.grid(row=1, column=i, padx=6, pady=2)
        ttk.Button(box, text="Add alert", style="Accent.TButton", command=self.add_alert).grid(row=1, column=4, padx=8)
        self.btn_check = ttk.Button(box, text="Check now", command=self.check_alerts)
        self.btn_check.grid(row=1, column=5)
        self._busy_buttons.append(self.btn_check)

        bar = ttk.Frame(tab)
        bar.pack(fill="x", padx=16)
        ttk.Button(bar, text="Delete selected", command=self.delete_alerts).pack(side="left")
        ttk.Button(bar, text="Re-arm selected", command=self.rearm_alerts).pack(side="left", padx=6)
        ttk.Label(bar, text="Alerts fire on live or fresh rates only - never on offline estimates.").pack(side="right")
        self.alert_tree = self._tree(tab, ("id", "pair", "cond", "status", "when"),
                                     ("ID", "Pair", "Condition", "Status", "Triggered"),
                                     (50, 100, 150, 200, 150), selectmode="extended")
        self.refresh_alerts()

    def _build_analytics(self, tab):
        self.stat_vars = {k: tk.StringVar(value="-") for k in
                          ("Total conversions", "Distinct pairs", "Most used pair", "Live-rate share")}
        row = ttk.Frame(tab)
        row.pack(fill="x", padx=16, pady=12)
        for i, (name, var) in enumerate(self.stat_vars.items()):
            card = ttk.LabelFrame(row, text=name, padding=10)
            card.grid(row=0, column=i, padx=6, sticky="ew")
            row.columnconfigure(i, weight=1)
            ttk.Label(card, textvariable=var, font=("Helvetica", 16, "bold")).pack()
        self.usage_canvas = self._canvas(tab, 180)
        self.usage_canvas.bind("<Configure>", lambda e: self._draw_usage())
        self.pair_tree = self._tree(tab, ("pair", "count", "avg", "min", "max"),
                                    ("Pair", "Count", "Avg rate", "Min rate", "Max rate"),
                                    (110, 80, 120, 120, 120), height=6)

    # ---------------------------------------------------------- widget helpers
    def _tree(self, parent, cols, headings, widths, selectmode="browse", height=None):
        kw = {"height": height} if height else {}
        tree = ttk.Treeview(parent, columns=cols, show="headings", selectmode=selectmode, **kw)
        for c, h, w in zip(cols, headings, widths):
            tree.heading(c, text=h)
            tree.column(c, width=w, anchor="w")
        sb = ttk.Scrollbar(parent, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=sb.set)
        sb.pack(side="right", fill="y", pady=8)
        tree.pack(expand=True, fill="both", padx=(12, 0), pady=8)
        return tree

    def _canvas(self, parent, height):
        c = tk.Canvas(parent, height=height, highlightthickness=1)
        c.pack(fill="x", padx=16)
        self._canvases.append(c)
        return c

    # ================================================================ theme
    def toggle_theme(self):
        self.settings.set_theme("dark" if self.settings.theme == "light" else "light")
        self._apply_theme()

    def _apply_theme(self):
        p = self.pal = theme.PALETTES[self.settings.theme]
        st = self.style
        st.theme_use("clam")
        self.configure(bg=p["bg"])
        st.configure(".", background=p["bg"], foreground=p["fg"], fieldbackground=p["field"],
                     bordercolor=p["border"])
        st.configure("TNotebook", background=p["bg"])
        st.configure("TNotebook.Tab", padding=(16, 7), background=p["panel"], foreground=p["fg"])
        st.map("TNotebook.Tab", background=[("selected", p["accent"])], foreground=[("selected", "#ffffff")])
        st.configure("TButton", padding=6, background=p["panel"], foreground=p["fg"])
        st.configure("Accent.TButton", padding=8, background=p["accent"], foreground="#ffffff")
        st.map("Accent.TButton", background=[("active", p["accent_hover"]), ("disabled", p["muted"])])
        st.configure("Treeview", background=p["field"], fieldbackground=p["field"], foreground=p["fg"],
                     rowheight=24)
        st.configure("Treeview.Heading", background=p["panel"], foreground=p["fg"])
        st.configure("TLabelframe", background=p["bg"])
        st.configure("TLabelframe.Label", background=p["bg"], foreground=p["fg"], font=("Helvetica", 10, "bold"))
        st.configure("Status.TLabel", background=p["panel"], foreground=p["muted"], padding=(8, 3))
        st.configure("Result.TLabel", font=("Helvetica", 22, "bold"))
        st.configure("good.Result.TLabel", foreground=p["good"])
        st.configure("warn.Result.TLabel", foreground=p["warn"])
        for c in self._canvases:
            c.configure(bg=p["field"], highlightbackground=p["border"])
        self._draw_trend()
        self._draw_usage()

    # ================================================================ async plumbing
    def _run_async(self, fn, on_ok, busy_msg):
        self._set_busy(True, busy_msg)

        def work():
            try:
                self._queue.put(("ok", on_ok, fn()))
            except CurrencyViewerError as exc:
                self._queue.put(("err", None, str(exc)))
            except Exception:  # last-resort guard so the UI never stays locked
                log.exception("Unexpected error in background task")
                self._queue.put(("err", None, "Unexpected error. Details were written to data/app.log."))

        threading.Thread(target=work, daemon=True).start()

    def _poll(self):
        try:
            while True:
                kind, callback, payload = self._queue.get_nowait()
                self._set_busy(False)
                if kind == "ok":
                    callback(payload)
                    self._flush_notifications()
                else:
                    self.status.set("Failed")
                    messagebox.showerror("Cannot complete request", payload)
        except queue.Empty:
            pass
        self.after(100, self._poll)

    def _flush_notifications(self):
        notes = self.svc.take_notifications()
        if notes:
            self.refresh_alerts()
            self.status.set("Rate alert triggered")
            messagebox.showinfo("Rate alert", "\n".join(notes))

    def _set_busy(self, busy, msg=""):
        for b in self._busy_buttons:
            b.config(state="disabled" if busy else "normal")
        if busy:
            self.status.set(msg)

    # ================================================================ converter
    def _swap(self):
        a, b = self.cmb_from.get(), self.cmb_to.get()
        self.cmb_from.set(b)
        self.cmb_to.set(a)
        self._sync_star()

    def convert(self, force=False):
        base, target, amount = self.cmb_from.get(), self.cmb_to.get(), self.ent_amt.get()
        self._run_async(lambda: self.svc.convert(base, target, amount, force),
                        self._show_result, "Fetching rate...")

    def _show_result(self, r):
        tone = presenter.source_tone(r.source)
        self.lbl_result.config(text=presenter.result_text(r), style=f"{tone}.Result.TLabel")
        self.lbl_detail.config(text=presenter.detail_text(r))
        self.status.set(f"Saved conversion #{r.id} ({r.source})")
        self.settings.set_last_pair(r.base, r.target)
        self.refresh_history()

    def _current_pair(self):
        return self.cmb_from.get(), self.cmb_to.get()

    def toggle_favourite(self):
        self.settings.toggle_favourite(*self._current_pair())
        self.cmb_fav.config(values=self.settings.favourites)
        self._sync_star()

    def _sync_star(self):
        pair = "/".join(self._current_pair())
        self.btn_star.config(text=presenter.star(pair in self.settings.favourites))

    def _use_favourite(self):
        base, target = self.cmb_fav.get().split("/")
        self.cmb_from.set(base)
        self.cmb_to.set(target)
        self._sync_star()

    # ================================================================ compare
    def compare(self):
        base, amount = self.cmp_from.get(), self.cmp_amt.get()
        self._run_async(lambda: self.svc.compare(base, amount), self._show_compare, "Fetching rates...")

    def _show_compare(self, payload):
        quote, rows = payload
        self.cmp_tree.delete(*self.cmp_tree.get_children())
        for row in rows:
            self.cmp_tree.insert("", "end", values=presenter.compare_row(row))
        self.lbl_cmp.config(text=f"Source: {quote.source}")
        self.status.set(f"Compared {len(rows)} currencies ({quote.source})")

    # ================================================================ alerts
    def add_alert(self):
        alert = self._guard(lambda: self.svc.add_alert(self.al_from.get(), self.al_to.get(),
                                                       self.al_dir.get(), self.al_val.get()))
        if alert:
            self.al_val.delete(0, "end")
            self.status.set(f"Alert #{alert.id} created for {alert.pair}")
            self.refresh_alerts()

    def check_alerts(self):
        self._run_async(self.svc.check_alerts, self._after_check, "Checking live rates...")

    def _after_check(self, fired):
        self.refresh_alerts()
        if fired:
            messagebox.showinfo("Rate alert", "\n".join(fired))
        else:
            self.status.set("No alerts triggered")

    def delete_alerts(self):
        ids = self.alert_tree.selection()
        if ids:
            self._guard(lambda: self.svc.delete_alerts(ids))
            self.refresh_alerts()

    def rearm_alerts(self):
        for i in self.alert_tree.selection():
            self._guard(lambda i=i: self.svc.rearm_alert(int(i)))
        self.refresh_alerts()

    def refresh_alerts(self):
        alerts = self._guard(self.svc.list_alerts) or []
        self.alert_tree.delete(*self.alert_tree.get_children())
        for a in alerts:
            self.alert_tree.insert("", "end", iid=str(a.id), values=presenter.alert_row(a))

    # ================================================================ history
    def refresh_history(self):
        term = self.search.get() if hasattr(self, "search") else None
        try:
            records = self.svc.history(term)
        except CurrencyViewerError as exc:
            self.status.set(str(exc))
            return
        self.tree.delete(*self.tree.get_children())
        for r in records:
            self.tree.insert("", "end", iid=str(r.id), values=presenter.history_row(r))
        self.status.set(f"{len(records)} history record(s)")

    def delete_selected(self):
        ids = self.tree.selection()
        if ids and messagebox.askyesno("Delete", f"Delete {len(ids)} selected record(s)?"):
            self._guard(lambda: self.svc.delete(ids))
            self.refresh_history()

    def clear_history(self):
        if messagebox.askyesno("Clear history", "Permanently delete ALL history?"):
            self._guard(self.svc.clear_history)
            self.refresh_history()

    def export_csv(self):
        path = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="conversions.csv",
                                            filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        n = self._guard(lambda: self.svc.export_history(path, self.search.get() or None))
        if n is not None:
            messagebox.showinfo("Export complete", f"Exported {n} record(s) to:\n{path}")

    def _guard(self, fn):
        try:
            return fn()
        except CurrencyViewerError as exc:
            messagebox.showerror("Error", str(exc))
            return None

    # ================================================================ tabs / charts
    def _on_tab(self):
        name = self.tabs.tab(self.tabs.select(), "text")
        if name == "Analytics":
            self._load_analytics()
        elif name == "Trends":
            self.show_trend()
        elif name == "Alerts":
            self.refresh_alerts()

    def _load_analytics(self):
        self._summary = self._guard(self.svc.analytics)
        if self._summary is None:
            return
        s = self._summary
        for var, v in zip(self.stat_vars.values(),
                          (str(s.total), str(s.unique_pairs), s.most_used_pair, f"{s.live_share_pct}%")):
            var.set(v)
        self.pair_tree.delete(*self.pair_tree.get_children())
        for p in s.pairs:
            self.pair_tree.insert("", "end", values=(p.pair, p.count, f"{p.avg_rate:.4f}",
                                                     f"{p.min_rate:.4f}", f"{p.max_rate:.4f}"))
        self._draw_usage()

    def load_history_data(self):
        base, target = self.tr_from.get(), self.tr_to.get()
        self._run_async(lambda: self.svc.backfill_history(base, target),
                        lambda n: (self.status.set(f"Added {n} historical point(s) for {base}/{target}"),
                                   self.show_trend()),
                        "Downloading history...")

    def show_trend(self):
        base, target = self.tr_from.get(), self.tr_to.get()
        series = self._guard(lambda: self.svc.rate_history(base, target))
        self._series = series or []
        self._trend_pair = f"{base}/{target}"
        if self._series:
            vals = [v for _, v in self._series]
            self.lbl_trend.config(text=f"{len(vals)} points | low {min(vals):.4f} | high {max(vals):.4f} "
                                       f"| latest {vals[-1]:.4f}")
        else:
            self.lbl_trend.config(text="")
        self._draw_trend()

    def _draw_trend(self):
        c = getattr(self, "trend_canvas", None)
        if c is None:
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 320), max(c.winfo_height(), 200)
        p = self.pal
        if len(self._series) < 2:
            c.create_text(w / 2, h / 2, fill=p["muted"],
                          text="Not enough data yet - convert (with internet) a few times over time.")
            return
        vals = [v for _, v in self._series]
        pts = charts.line_points(vals, w, h)
        for frac in (0.0, 0.5, 1.0):
            y = 34 + (h - 68) * frac
            c.create_line(34, y, w - 34, y, fill=p["grid"])
        c.create_text(34, 14, anchor="w", fill=p["muted"], text=f"{self._trend_pair}  high {max(vals):.4f}")
        c.create_text(34, h - 12, anchor="w", fill=p["muted"], text=f"low {min(vals):.4f}")
        c.create_line(*[xy for pt in pts for xy in pt], fill=p["accent"], width=2)
        for x, y in pts:
            c.create_oval(x - 3, y - 3, x + 3, y + 3, fill=p["accent"], outline="")

    def _draw_usage(self):
        c = getattr(self, "usage_canvas", None)
        if c is None:
            return
        c.delete("all")
        w, h = max(c.winfo_width(), 320), max(c.winfo_height(), 160)
        p = self.pal
        top = self._summary.pairs[:8] if self._summary else []
        boxes = charts.bar_boxes([x.count for x in top], w, h)
        if not boxes:
            c.create_text(w / 2, h / 2, fill=p["muted"], text="No conversions yet")
            return
        for stat, (x0, y0, x1, y1) in zip(top, boxes):
            c.create_rectangle(x0, y0, x1, y1, fill=p["accent"], outline="")
            c.create_text((x0 + x1) / 2, y0 - 9, text=str(stat.count), fill=p["fg"])
            c.create_text((x0 + x1) / 2, y1 + 12, text=stat.pair, fill=p["muted"])
