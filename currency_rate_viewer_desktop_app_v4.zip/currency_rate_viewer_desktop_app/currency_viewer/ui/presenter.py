"""Pure formatting helpers for the UI (unit-tested; no tkinter import)."""

from typing import Tuple

from ..models import SOURCE_CACHED, SOURCE_LIVE, Alert, CompareRow, ConversionRecord


def money(value) -> str:
    return f"{value:,}"


def result_text(r: ConversionRecord) -> str:
    return f"{money(r.amount)} {r.base} = {money(r.result)} {r.target}"


def detail_text(r: ConversionRecord) -> str:
    return f"1 {r.base} = {r.rate} {r.target}   |   Source: {r.source}"


def source_tone(source: str) -> str:
    """'good' for trustworthy data, 'warn' for stale/estimated rates."""
    return "good" if source in (SOURCE_LIVE, SOURCE_CACHED) else "warn"


def history_row(r: ConversionRecord) -> Tuple:
    return (r.id, r.created_at.strftime("%Y-%m-%d %H:%M"), r.pair,
            money(r.amount), r.rate, money(r.result), r.source)


def compare_row(c: CompareRow) -> Tuple:
    return (c.code, c.name, c.rate, money(c.converted))


def star(is_favourite: bool) -> str:
    return "★" if is_favourite else "☆"


def alert_row(a: Alert) -> Tuple:
    condition = f"{a.direction} {a.threshold.normalize():f}"
    if a.active:
        status, when = "Active", ""
    else:
        status = f"Triggered at {a.triggered_rate.normalize():f}"
        when = a.triggered_at.strftime("%Y-%m-%d %H:%M")
    return (a.id, a.pair, condition, status, when)
