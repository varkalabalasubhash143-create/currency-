"""Persisted user preferences (theme, last pair, favourite pairs).

Loaded defensively: a hand-edited or corrupt file falls back to defaults.
"""

import json
from pathlib import Path
from typing import List

from .config import CURRENCIES

MAX_FAVOURITES = 20
THEMES = ("light", "dark")
DEFAULTS = {"theme": "light", "last_from": "USD", "last_to": "INR", "favourites": []}


def _clean(raw: dict) -> dict:
    out = dict(DEFAULTS)
    if raw.get("theme") in THEMES:
        out["theme"] = raw["theme"]
    for key in ("last_from", "last_to"):
        if raw.get(key) in CURRENCIES:
            out[key] = raw[key]
    favs: List[str] = []
    for pair in raw.get("favourites", []) if isinstance(raw.get("favourites"), list) else []:
        parts = pair.split("/") if isinstance(pair, str) else []
        if len(parts) == 2 and all(p in CURRENCIES for p in parts) and pair not in favs:
            favs.append(pair)
    out["favourites"] = favs[:MAX_FAVOURITES]
    return out


class SettingsStore:
    def __init__(self, path: Path):
        self._path = Path(path)
        try:
            raw = json.loads(self._path.read_text(encoding="utf-8"))
            self._data = _clean(raw if isinstance(raw, dict) else {})
        except (OSError, ValueError):
            self._data = dict(DEFAULTS, favourites=[])

    @property
    def theme(self) -> str:
        return self._data["theme"]

    @property
    def favourites(self) -> List[str]:
        return list(self._data["favourites"])

    @property
    def last_pair(self):
        return self._data["last_from"], self._data["last_to"]

    def set_theme(self, theme: str) -> None:
        if theme in THEMES:
            self._data["theme"] = theme
            self._save()

    def set_last_pair(self, base: str, target: str) -> None:
        if base in CURRENCIES and target in CURRENCIES:
            self._data["last_from"], self._data["last_to"] = base, target
            self._save()

    def toggle_favourite(self, base: str, target: str) -> bool:
        """Adds or removes the pair. Returns True if it is now a favourite."""
        pair = f"{base}/{target}"
        favs = self._data["favourites"]
        if pair in favs:
            favs.remove(pair)
            now = False
        elif base in CURRENCIES and target in CURRENCIES and len(favs) < MAX_FAVOURITES:
            favs.append(pair)
            now = True
        else:
            return False
        self._save()
        return now

    def _save(self) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self._path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._data, indent=2), encoding="utf-8")
            tmp.replace(self._path)
        except OSError:
            pass  # preferences are non-critical
