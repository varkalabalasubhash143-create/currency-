"""SQLite persistence for conversion history. All SQL is parameterised."""

import csv
import sqlite3
from contextlib import closing
from datetime import datetime
from decimal import Decimal
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple

from .errors import StorageError
from .models import Alert, ConversionRecord

_SCHEMA = """
CREATE TABLE IF NOT EXISTS conversions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    base TEXT NOT NULL,
    target TEXT NOT NULL,
    amount TEXT NOT NULL,
    rate TEXT NOT NULL,
    result TEXT NOT NULL,
    source TEXT NOT NULL
)"""

_SNAP_SCHEMA = """
CREATE TABLE IF NOT EXISTS rate_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    taken_at TEXT NOT NULL,
    base TEXT NOT NULL,
    target TEXT NOT NULL,
    rate TEXT NOT NULL
)"""
_SNAP_INDEX = ("CREATE UNIQUE INDEX IF NOT EXISTS idx_snap_uq "
               "ON rate_snapshots (base, target, taken_at)")  # also makes backfills idempotent
_ALERT_SCHEMA = """
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL,
    base TEXT NOT NULL,
    target TEXT NOT NULL,
    direction TEXT NOT NULL CHECK (direction IN ('above', 'below')),
    threshold TEXT NOT NULL,
    triggered_at TEXT,
    triggered_rate TEXT
)"""

CSV_FIELDS = ["id", "created_at", "base", "target", "amount", "rate", "result", "source"]


class ConversionRepository:
    def __init__(self, db_path: Path):
        self._db_path = Path(db_path)
        try:
            self._db_path.parent.mkdir(parents=True, exist_ok=True)
            with closing(self._connect()) as conn, conn:
                conn.execute(_SCHEMA)
                conn.execute(_SNAP_SCHEMA)
                conn.execute(_SNAP_INDEX)
                conn.execute(_ALERT_SCHEMA)
        except (OSError, sqlite3.Error) as exc:
            raise StorageError(f"Cannot open database: {exc}") from exc

    def _connect(self) -> sqlite3.Connection:
        # One short-lived connection per call keeps this safe across threads.
        return sqlite3.connect(self._db_path)

    # -- commands ----------------------------------------------------------
    def add(self, rec: ConversionRecord) -> ConversionRecord:
        try:
            with closing(self._connect()) as conn, conn:
                cur = conn.execute(
                    "INSERT INTO conversions (created_at, base, target, amount, rate, result, source) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    (rec.created_at.isoformat(timespec="seconds"), rec.base, rec.target,
                     str(rec.amount), str(rec.rate), str(rec.result), rec.source))
                new_id = cur.lastrowid
        except sqlite3.Error as exc:
            raise StorageError(f"Could not save conversion: {exc}") from exc
        return ConversionRecord(**{**rec.__dict__, "id": new_id})

    def delete(self, ids: Iterable[int]) -> int:
        ids = [int(i) for i in ids]
        if not ids:
            return 0
        marks = ",".join("?" * len(ids))
        try:
            with closing(self._connect()) as conn, conn:
                return conn.execute(f"DELETE FROM conversions WHERE id IN ({marks})", ids).rowcount
        except sqlite3.Error as exc:
            raise StorageError(f"Could not delete records: {exc}") from exc

    def clear(self) -> None:
        try:
            with closing(self._connect()) as conn, conn:
                conn.execute("DELETE FROM conversions")
        except sqlite3.Error as exc:
            raise StorageError(f"Could not clear history: {exc}") from exc

    # -- rate snapshots (history of live rates, used for the trend chart) ---
    def add_snapshots(self, taken_at: datetime, base: str, rates: Dict[str, Decimal],
                      min_interval_seconds: int = 300) -> int:
        """Store one row per target. Skipped if this base was snapshotted very recently."""
        try:
            with closing(self._connect()) as conn, conn:
                last = conn.execute("SELECT MAX(taken_at) FROM rate_snapshots WHERE base = ?",
                                    (base,)).fetchone()[0]
                if last and (taken_at - datetime.fromisoformat(last)).total_seconds() < min_interval_seconds:
                    return 0
                conn.executemany(
                    "INSERT OR IGNORE INTO rate_snapshots (taken_at, base, target, rate) VALUES (?, ?, ?, ?)",
                    [(taken_at.isoformat(timespec="seconds"), base, t, str(r))
                     for t, r in rates.items() if t != base])
                return len(rates) - (1 if base in rates else 0)
        except sqlite3.Error as exc:
            raise StorageError(f"Could not save rate snapshot: {exc}") from exc

    def add_series(self, base: str, target: str, points: List[Tuple[datetime, Decimal]]) -> int:
        """Bulk-insert historical points; duplicates (same pair + timestamp) are ignored."""
        try:
            with closing(self._connect()) as conn, conn:
                cur = conn.executemany(
                    "INSERT OR IGNORE INTO rate_snapshots (taken_at, base, target, rate) VALUES (?, ?, ?, ?)",
                    [(t.isoformat(timespec="seconds"), base, target, str(r)) for t, r in points])
                return cur.rowcount
        except sqlite3.Error as exc:
            raise StorageError(f"Could not save rate history: {exc}") from exc

    def snapshot_series(self, base: str, target: str, limit: int = 100) -> List[Tuple[datetime, Decimal]]:
        """Most recent `limit` snapshots for a pair, oldest first."""
        try:
            with closing(self._connect()) as conn:
                rows = conn.execute(
                    "SELECT taken_at, rate FROM rate_snapshots WHERE base = ? AND target = ? "
                    "ORDER BY taken_at DESC, id DESC LIMIT ?", (base, target, int(limit))).fetchall()
        except sqlite3.Error as exc:
            raise StorageError(f"Could not read rate history: {exc}") from exc
        return [(datetime.fromisoformat(t), Decimal(r)) for t, r in reversed(rows)]

    # -- alerts --------------------------------------------------------------
    def add_alert(self, alert: Alert) -> Alert:
        try:
            with closing(self._connect()) as conn, conn:
                cur = conn.execute(
                    "INSERT INTO alerts (created_at, base, target, direction, threshold) VALUES (?, ?, ?, ?, ?)",
                    (alert.created_at.isoformat(timespec="seconds"), alert.base, alert.target,
                     alert.direction, str(alert.threshold)))
                new_id = cur.lastrowid
        except sqlite3.Error as exc:
            raise StorageError(f"Could not save alert: {exc}") from exc
        return Alert(**{**alert.__dict__, "id": new_id})

    def list_alerts(self, active_only: bool = False) -> List[Alert]:
        sql = ("SELECT id, created_at, base, target, direction, threshold, triggered_at, triggered_rate "
               "FROM alerts")
        if active_only:
            sql += " WHERE triggered_at IS NULL"
        try:
            with closing(self._connect()) as conn:
                rows = conn.execute(sql + " ORDER BY id").fetchall()
        except sqlite3.Error as exc:
            raise StorageError(f"Could not read alerts: {exc}") from exc
        return [Alert(id=r[0], created_at=datetime.fromisoformat(r[1]), base=r[2], target=r[3],
                      direction=r[4], threshold=Decimal(r[5]),
                      triggered_at=datetime.fromisoformat(r[6]) if r[6] else None,
                      triggered_rate=Decimal(r[7]) if r[7] else None) for r in rows]

    def mark_triggered(self, alert_id: int, when: datetime, rate: Decimal) -> None:
        self._exec("UPDATE alerts SET triggered_at = ?, triggered_rate = ? WHERE id = ?",
                   (when.isoformat(timespec="seconds"), str(rate), int(alert_id)), "update alert")

    def rearm_alert(self, alert_id: int) -> None:
        self._exec("UPDATE alerts SET triggered_at = NULL, triggered_rate = NULL WHERE id = ?",
                   (int(alert_id),), "re-arm alert")

    def delete_alerts(self, ids: Iterable[int]) -> int:
        ids = [int(i) for i in ids]
        if not ids:
            return 0
        return self._exec(f"DELETE FROM alerts WHERE id IN ({','.join('?' * len(ids))})", ids, "delete alerts")

    def _exec(self, sql: str, params, what: str) -> int:
        try:
            with closing(self._connect()) as conn, conn:
                return conn.execute(sql, params).rowcount
        except sqlite3.Error as exc:
            raise StorageError(f"Could not {what}: {exc}") from exc

    # -- queries -----------------------------------------------------------
    def list(self, search: Optional[str] = None, limit: Optional[int] = None) -> List[ConversionRecord]:
        sql = "SELECT id, created_at, base, target, amount, rate, result, source FROM conversions"
        params: list = []
        if search:
            sql += " WHERE base LIKE ? OR target LIKE ? OR source LIKE ?"
            like = f"%{search.strip()}%"
            params += [like, like, like]
        sql += " ORDER BY id DESC"
        if limit:
            sql += " LIMIT ?"
            params.append(int(limit))
        try:
            with closing(self._connect()) as conn:
                rows = conn.execute(sql, params).fetchall()
        except sqlite3.Error as exc:
            raise StorageError(f"Could not read history: {exc}") from exc
        return [ConversionRecord(id=r[0], created_at=datetime.fromisoformat(r[1]), base=r[2],
                                 target=r[3], amount=Decimal(r[4]), rate=Decimal(r[5]),
                                 result=Decimal(r[6]), source=r[7]) for r in rows]

    def export_csv(self, path: Path, records: Optional[List[ConversionRecord]] = None) -> int:
        records = self.list() if records is None else records
        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                writer = csv.writer(fh)
                writer.writerow(CSV_FIELDS)
                for r in records:
                    writer.writerow([r.id, r.created_at.isoformat(sep=" ", timespec="seconds"),
                                     r.base, r.target, r.amount, r.rate, r.result, r.source])
        except OSError as exc:
            raise StorageError(f"Could not write CSV: {exc}") from exc
        return len(records)
