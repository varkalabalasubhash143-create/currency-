#!/usr/bin/env sh
# Optional: package as a single-file desktop executable (needs: pip install pyinstaller)
pyinstaller --onefile --windowed --name CurrencyRateViewer main.py
