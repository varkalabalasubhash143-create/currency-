# Architecture

```
            +---------------------------------------------+
 PRESENT.   | ui/app.py  (Tkinter)                        |
            | ui/presenter.py  ui/theme.py  charts.py     |  formatting, colours, geometry (pure)
            +----------------------+----------------------+
                                   | calls only
            +----------------------v----------------------+
 APPLICATION| service.py  ConverterService                |  validate -> rates -> maths -> save
            | validators.py  analytics.py  settings.py    |
            | alerts.py (rules)                           |
            +-----------+---------------------+-----------+
                        |                     |
            +-----------v---------+  +--------v-----------+
 DATA       | rate_service.py     |  | repository.py      |
            | history_service.py  |  | (+ alerts table)   |
            | cache -> API ->     |  | SQLite: history +  |
            | stale -> offline    |  | rate snapshots,CSV |
            +---------------------+  +--------------------+
```

## Rules
1. Dependencies point downward only. `ui` imports `service`; nothing imports `ui`.
2. `main.py` is the only place objects are constructed and wired (composition root).
3. I/O is injected (`fetcher`, `clock`, db path) so every non-UI module is unit-tested with no network and no GUI.
4. User-facing failures are `CurrencyViewerError` subclasses; unexpected errors are logged to `data/app.log` and shown as a generic message.

## Key flows
**Convert**: UI -> worker thread -> `ConverterService.convert` -> validate -> `RateService.get_quote`
(fresh cache | live | stale cache | offline table) -> Decimal maths (round half-up) -> save record ->
if the quote was *Live*, store a rate snapshot (throttled to one per 5 min per base) -> UI callback via queue.

**Trends**: snapshots recorded by live fetches are read back as a time series and drawn by `charts.line_points`.

**Alerts**: every fresh quote (live or cached) is evaluated against active alerts; matches are marked triggered
(one-shot) and queued as notifications that the UI shows once. Offline estimates are never evaluated.

**History backfill**: `history_service` downloads a date range, `parse_series` validates it (bad rows skipped),
`repository.add_series` inserts with `INSERT OR IGNORE` on a unique (base, target, time) index so repeated downloads are safe.

## Design decisions
- `Decimal` for money, stored as text in SQLite, so no precision loss on round trip.
- Offline estimates are clearly labelled and never recorded as trend data, so approximate numbers cannot pollute history.
- Settings are sanitised on load; a hand-edited file cannot crash the app.
