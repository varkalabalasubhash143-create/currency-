"""Entry point / composition root: wires the layers together."""

from currency_viewer import config, logging_setup
from currency_viewer.rate_service import RateService
from currency_viewer.repository import ConversionRepository
from currency_viewer.service import ConverterService
from currency_viewer.settings import SettingsStore
from currency_viewer.ui.app import App


def main() -> None:
    logging_setup.configure(config.DATA_DIR)
    service = ConverterService(RateService(config.CACHE_FILE), ConversionRepository(config.DB_FILE))
    App(service, SettingsStore(config.SETTINGS_FILE)).mainloop()


if __name__ == "__main__":
    main()
