import json
import tempfile
import unittest
from datetime import date, datetime, timedelta
from decimal import Decimal
from pathlib import Path

from currency_viewer import alerts
from currency_viewer.errors import RateFetchError, ValidationError
from currency_viewer.history_service import parse_series
from currency_viewer.models import Alert
from currency_viewer.rate_service import RateService
from currency_viewer.repository import ConversionRepository
from currency_viewer.service import ConverterService
from currency_viewer.ui import presenter


class AlertRuleTests(unittest.TestCase):
    def test_trigger_boundaries(self):
        d = Decimal
        self.assertTrue(alerts.is_triggered("above", d(85), d(85)))
        self.assertTrue(alerts.is_triggered("above", d(85), d("85.1")))
        self.assertFalse(alerts.is_triggered("above", d(85), d("84.9")))
        self.assertTrue(alerts.is_triggered("below", d(85), d(85)))
        self.assertFalse(alerts.is_triggered("below", d(85), d("85.1")))

    def test_direction_validation_and_message(self):
        self.assertEqual(alerts.validate_direction(" ABOVE "), "above")
        with self.assertRaises(ValidationError):
            alerts.validate_direction("sideways")
        a = Alert("USD", "INR", "above", Decimal("85.0"), datetime(2026, 1, 1))
        self.assertEqual(alerts.message(a, Decimal("85.50")), "USD/INR is 85.5, above your target of 85")


class HistoryParseTests(unittest.TestCase):
    def test_parses_and_sorts(self):
        payload = {"rates": {"2026-01-03": {"INR": 83.3}, "2026-01-02": {"INR": 83.1}}}
        pts = parse_series(payload, "INR")
        self.assertEqual([p[0].day for p in pts], [2, 3])
        self.assertEqual(pts[0][1], Decimal("83.1"))

    def test_skips_bad_rows_but_fails_when_nothing_usable(self):
        good = parse_series({"rates": {"2026-01-02": {"INR": 83}, "bad-date": {"INR": 1},
                                       "2026-01-04": {"EUR": 1}, "2026-01-05": {"INR": -1}}}, "INR")
        self.assertEqual(len(good), 1)
        for bad in [{}, {"rates": {}}, {"rates": {"2026-01-02": {"EUR": 1}}}, None, []]:
            with self.subTest(bad=bad), self.assertRaises(RateFetchError):
                parse_series(bad, "INR")


class ServiceAlertTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)
        self.rate = 80
        self.hist_calls = []

        def fetch(base):
            return {"USD": 1, "INR": self.rate, "EUR": 0.5}

        def hist(base, target, start, end):
            self.hist_calls.append((base, target, start, end))
            n = (end - start).days
            return [(datetime.combine(start + timedelta(days=i), datetime.min.time()).replace(hour=12),
                     Decimal(80 + i)) for i in range(n)]

        self.repo = ConversionRepository(self.d / "t.db")
        self.svc = ConverterService(RateService(self.d / "c.json", fetch, ttl_seconds=0), self.repo, hist)

    def tearDown(self):
        self.tmp.cleanup()

    def test_add_validates(self):
        bad = [("USD", "USD", "above", "5"), ("USD", "INR", "up", "5"), ("USD", "INR", "above", "0"),
               ("USD", "INR", "above", "abc"), ("XXX", "INR", "above", "5")]
        for args in bad:
            with self.subTest(args=args), self.assertRaises(ValidationError):
                self.svc.add_alert(*args)
        self.assertEqual(self.svc.list_alerts(), [])

    def test_alert_fires_once_and_can_be_rearmed(self):
        a = self.svc.add_alert("USD", "INR", "above", "85")
        self.assertEqual(self.svc.check_alerts(), [])           # 80 < 85
        self.rate = 90
        fired = self.svc.check_alerts()
        self.assertEqual(len(fired), 1)
        self.assertIn("USD/INR is 90", fired[0])
        self.assertEqual(self.svc.check_alerts(), [])           # one-shot
        self.assertFalse(self.svc.list_alerts()[0].active)
        self.svc.rearm_alert(a.id)
        self.assertEqual(len(self.svc.check_alerts()), 1)

    def test_conversion_triggers_notification_as_side_effect(self):
        self.svc.add_alert("USD", "INR", "below", "81")
        self.svc.convert("USD", "INR", "1")                      # live rate 80 <= 81
        notes = self.svc.take_notifications()
        self.assertEqual(len(notes), 1)
        self.assertEqual(self.svc.take_notifications(), [])      # delivered once

    def test_offline_estimates_never_trigger(self):
        def down(_):
            raise RateFetchError("down")
        svc = ConverterService(RateService(self.d / "c2.json", down), self.repo)
        svc.add_alert("USD", "INR", "above", "1")                # offline estimate is 83 >= 1
        self.assertEqual(svc.check_alerts(), [])
        svc.convert("USD", "INR", "1")
        self.assertEqual(svc.take_notifications(), [])
        self.assertTrue(svc.list_alerts()[0].active)

    def test_alert_limit_and_delete(self):
        from currency_viewer.config import MAX_ALERTS
        for _ in range(MAX_ALERTS):
            self.svc.add_alert("USD", "INR", "above", "999")
        with self.assertRaises(ValidationError):
            self.svc.add_alert("USD", "INR", "above", "999")
        ids = [a.id for a in self.svc.list_alerts()[:3]]
        self.assertEqual(self.svc.delete_alerts(ids), 3)

    def test_backfill_is_validated_and_idempotent(self):
        added = self.svc.backfill_history("USD", "INR", 10)
        self.assertEqual(added, 10)
        self.assertEqual(self.svc.backfill_history("USD", "INR", 10), 0)   # same points ignored
        series = self.svc.rate_history("USD", "INR")
        self.assertEqual(len(series), 10)
        self.assertEqual(series, sorted(series))
        self.assertEqual(self.hist_calls[0][3], date.today())
        for args in [("USD", "USD", 5), ("USD", "INR", 0), ("USD", "INR", 9999), ("XXX", "INR", 5)]:
            with self.subTest(args=args), self.assertRaises(ValidationError):
                self.svc.backfill_history(*args)

    def test_backfill_error_propagates_as_friendly_error(self):
        def broken(*a):
            raise RateFetchError("History not available")
        svc = ConverterService(RateService(self.d / "c3.json", lambda b: {"INR": 1}), self.repo, broken)
        with self.assertRaises(RateFetchError):
            svc.backfill_history("USD", "AED", 5)

    def test_presenter_alert_rows(self):
        a = self.svc.add_alert("USD", "INR", "above", "85.50")
        self.assertEqual(presenter.alert_row(a), (a.id, "USD/INR", "above 85.5", "Active", ""))
        self.rate = 90
        self.svc.check_alerts()
        row = presenter.alert_row(self.svc.list_alerts()[0])
        self.assertEqual(row[3], "Triggered at 90")


if __name__ == "__main__":
    unittest.main()
