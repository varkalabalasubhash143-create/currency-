import json
import tempfile
import unittest
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from currency_viewer import charts
from currency_viewer.models import CompareRow, ConversionRecord
from currency_viewer.settings import MAX_FAVOURITES, SettingsStore
from currency_viewer.ui import presenter, theme


class ChartTests(unittest.TestCase):
    def test_line_points_scale_and_orientation(self):
        pts = charts.line_points([Decimal(1), Decimal(2), Decimal(3)], 200, 100, pad=10)
        self.assertEqual(pts[0], (10, 90))      # lowest value at bottom-left
        self.assertEqual(pts[-1], (190, 10))    # highest value at top-right

    def test_flat_and_single_and_empty_series(self):
        flat = charts.line_points([Decimal(5), Decimal(5)], 200, 100, pad=10)
        self.assertEqual({y for _, y in flat}, {50.0})
        self.assertEqual(charts.line_points([Decimal(5)], 200, 100)[0][0], 100)
        self.assertEqual(charts.line_points([], 200, 100), [])

    def test_bar_boxes(self):
        boxes = charts.bar_boxes([4, 2], 200, 100, pad=10)
        self.assertEqual(len(boxes), 2)
        self.assertAlmostEqual(boxes[0][1], 10)               # tallest bar reaches the top
        self.assertAlmostEqual(boxes[1][3] - boxes[1][1], (boxes[0][3] - boxes[0][1]) / 2)
        self.assertEqual(charts.bar_boxes([], 200, 100), [])
        self.assertEqual(charts.bar_boxes([0, 0], 200, 100), [])


class SettingsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = Path(self.tmp.name) / "s.json"

    def tearDown(self):
        self.tmp.cleanup()

    def test_defaults_and_persistence(self):
        s = SettingsStore(self.path)
        self.assertEqual((s.theme, s.last_pair, s.favourites), ("light", ("USD", "INR"), []))
        s.set_theme("dark")
        s.set_last_pair("EUR", "GBP")
        self.assertTrue(s.toggle_favourite("EUR", "GBP"))
        again = SettingsStore(self.path)
        self.assertEqual((again.theme, again.last_pair, again.favourites), ("dark", ("EUR", "GBP"), ["EUR/GBP"]))

    def test_toggle_removes(self):
        s = SettingsStore(self.path)
        s.toggle_favourite("USD", "INR")
        self.assertFalse(s.toggle_favourite("USD", "INR"))
        self.assertEqual(s.favourites, [])

    def test_rejects_invalid_values(self):
        s = SettingsStore(self.path)
        s.set_theme("neon")
        s.set_last_pair("XXX", "INR")
        self.assertFalse(s.toggle_favourite("XXX", "INR"))
        self.assertEqual((s.theme, s.last_pair), ("light", ("USD", "INR")))

    def test_corrupt_or_tampered_file_is_sanitised(self):
        self.path.write_text("{oops")
        self.assertEqual(SettingsStore(self.path).theme, "light")
        self.path.write_text(json.dumps({"theme": "x", "last_from": "ZZZ",
                                         "favourites": ["USD/INR", "USD/INR", "bad", 5, "AAA/BBB"]}))
        s = SettingsStore(self.path)
        self.assertEqual((s.theme, s.last_pair, s.favourites), ("light", ("USD", "INR"), ["USD/INR"]))

    def test_favourite_limit(self):
        s = SettingsStore(self.path)
        codes = ["USD", "INR", "EUR", "GBP", "JPY", "AED", "CAD", "AUD", "CHF", "CNY", "SGD", "NZD"]
        pairs = [(a, b) for a in codes for b in codes if a != b]
        for a, b in pairs[:MAX_FAVOURITES + 5]:
            s.toggle_favourite(a, b)
        self.assertEqual(len(s.favourites), MAX_FAVOURITES)


class PresenterTests(unittest.TestCase):
    def setUp(self):
        self.r = ConversionRecord("USD", "INR", Decimal("1500"), Decimal("83.5"), Decimal("125250.00"),
                                  "Live", datetime(2026, 3, 4, 5, 6), id=7)

    def test_texts(self):
        self.assertEqual(presenter.result_text(self.r), "1,500 USD = 125,250.00 INR")
        self.assertIn("1 USD = 83.5 INR", presenter.detail_text(self.r))
        self.assertEqual(presenter.history_row(self.r)[:3], (7, "2026-03-04 05:06", "USD/INR"))

    def test_tone_and_star(self):
        self.assertEqual(presenter.source_tone("Live"), "good")
        self.assertEqual(presenter.source_tone("Offline estimate"), "warn")
        self.assertEqual(presenter.source_tone("Cached (stale)"), "warn")
        self.assertNotEqual(presenter.star(True), presenter.star(False))

    def test_compare_row(self):
        self.assertEqual(presenter.compare_row(CompareRow("EUR", "Euro", Decimal("0.9"), Decimal("1234.5"))),
                         ("EUR", "Euro", Decimal("0.9"), "1,234.5"))

    def test_both_palettes_have_same_keys(self):
        self.assertEqual(set(theme.PALETTES["light"]), set(theme.PALETTES["dark"]))


if __name__ == "__main__":
    unittest.main()
