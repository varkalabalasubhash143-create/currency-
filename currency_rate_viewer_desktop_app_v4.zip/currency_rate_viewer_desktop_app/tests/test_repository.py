import tempfile
import unittest
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from currency_viewer.models import ConversionRecord
from currency_viewer.repository import ConversionRepository


def rec(base="USD", target="INR", amount="100", rate="83.5", source="Live", ts=None):
    a, r = Decimal(amount), Decimal(rate)
    return ConversionRecord(base, target, a, r, a * r, source, ts or datetime(2026, 1, 2, 3, 4, 5))


class RepositoryTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.dir = Path(self.tmp.name)
        self.repo = ConversionRepository(self.dir / "t.db")

    def tearDown(self):
        self.tmp.cleanup()

    def test_add_and_list_roundtrip_keeps_decimal_precision(self):
        saved = self.repo.add(rec(amount="0.10", rate="0.123456"))
        self.assertEqual(saved.id, 1)
        got = self.repo.list()[0]
        self.assertEqual((got.amount, got.rate), (Decimal("0.10"), Decimal("0.123456")))

    def test_persists_across_instances(self):
        self.repo.add(rec())
        self.assertEqual(len(ConversionRepository(self.dir / "t.db").list()), 1)

    def test_search_and_order(self):
        self.repo.add(rec("USD", "INR"))
        self.repo.add(rec("EUR", "GBP"))
        self.assertEqual([r.base for r in self.repo.list()], ["EUR", "USD"])
        self.assertEqual([r.base for r in self.repo.list(search="GBP")], ["EUR"])

    def test_sql_injection_text_is_inert(self):
        self.repo.add(rec())
        self.assertEqual(self.repo.list(search="'; DROP TABLE conversions;--"), [])
        self.assertEqual(len(self.repo.list()), 1)

    def test_delete_and_clear(self):
        a = self.repo.add(rec())
        self.repo.add(rec("EUR", "GBP"))
        self.assertEqual(self.repo.delete([a.id]), 1)
        self.assertEqual(len(self.repo.list()), 1)
        self.repo.clear()
        self.assertEqual(self.repo.list(), [])

    def test_export_csv(self):
        self.repo.add(rec())
        out = self.dir / "o.csv"
        self.assertEqual(self.repo.export_csv(out), 1)
        lines = out.read_text(encoding="utf-8-sig").splitlines()
        self.assertEqual(lines[0], "id,created_at,base,target,amount,rate,result,source")
        self.assertIn("USD,INR,100,83.5", lines[1])


if __name__ == "__main__":
    unittest.main()
