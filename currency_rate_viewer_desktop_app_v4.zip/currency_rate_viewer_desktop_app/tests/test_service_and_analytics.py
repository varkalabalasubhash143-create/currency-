import tempfile
import unittest
from datetime import datetime
from decimal import Decimal
from pathlib import Path

from currency_viewer.analytics import summarize
from currency_viewer.errors import RateFetchError, ValidationError
from currency_viewer.models import ConversionRecord
from currency_viewer.rate_service import RateService
from currency_viewer.repository import ConversionRepository
from currency_viewer.service import ConverterService


class ServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        d = Path(self.tmp.name)
        fetch = lambda base: {"USD": 1, "INR": 83.333333, "EUR": 0.9}
        self.svc = ConverterService(RateService(d / "c.json", fetch), ConversionRepository(d / "t.db"))

    def tearDown(self):
        self.tmp.cleanup()

    def test_convert_rounds_half_up_and_saves(self):
        r = self.svc.convert("usd", "inr", "10")
        self.assertEqual(r.result, Decimal("833.33"))
        self.assertEqual(r.source, "Live")
        self.assertEqual(len(self.svc.history()), 1)

    def test_invalid_input_saves_nothing(self):
        for args in [("USD", "INR", "-1"), ("USD", "ZZZ", "5"), ("USD", "INR", "x")]:
            with self.subTest(args=args), self.assertRaises(ValidationError):
                self.svc.convert(*args)
        self.assertEqual(self.svc.history(), [])

    def test_missing_target_rate(self):
        with self.assertRaises(ValidationError):
            self.svc.convert("USD", "JPY", "5")  # fetcher has no JPY

    def test_works_fully_offline(self):
        d = Path(self.tmp.name)

        def down(_):
            raise RateFetchError("down")
        svc = ConverterService(RateService(d / "c2.json", down), ConversionRepository(d / "t2.db"))
        self.assertEqual(svc.convert("USD", "INR", "1").source, "Offline estimate")

    def test_export_and_analytics_end_to_end(self):
        self.svc.convert("USD", "INR", "1")
        self.svc.convert("USD", "INR", "2")
        self.svc.convert("USD", "EUR", "3")
        out = Path(self.tmp.name) / "x.csv"
        self.assertEqual(self.svc.export_history(out), 3)
        s = self.svc.analytics()
        self.assertEqual((s.total, s.unique_pairs, s.most_used_pair), (3, 2, "USD/INR"))


class AnalyticsTests(unittest.TestCase):
    def test_empty(self):
        s = summarize([])
        self.assertEqual((s.total, s.most_used_pair, s.pairs), (0, "-", []))

    def test_stats(self):
        mk = lambda rate, src: ConversionRecord("USD", "INR", Decimal(1), Decimal(rate), Decimal(rate),
                                                src, datetime(2026, 5, 1))
        s = summarize([mk("80", "Live"), mk("90", "Offline estimate")])
        p = s.pairs[0]
        self.assertEqual((p.count, p.avg_rate, p.min_rate, p.max_rate), (2, Decimal(85), Decimal(80), Decimal(90)))
        self.assertEqual(s.live_share_pct, 50.0)
        self.assertEqual(s.per_day, {"2026-05-01": 2})


if __name__ == "__main__":
    unittest.main()
