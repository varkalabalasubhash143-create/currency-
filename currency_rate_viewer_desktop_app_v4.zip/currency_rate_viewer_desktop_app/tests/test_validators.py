import unittest
from decimal import Decimal

from currency_viewer.errors import ValidationError
from currency_viewer.validators import validate_amount, validate_currency


class AmountTests(unittest.TestCase):
    def test_valid(self):
        self.assertEqual(validate_amount("1,250.50"), Decimal("1250.50"))
        self.assertEqual(validate_amount("  7 "), Decimal("7"))

    def test_rejects_bad_input(self):
        for bad in ["", "   ", "abc", "0", "-5", "NaN", "Infinity", "1e99", "12abc"]:
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                validate_amount(bad)

    def test_none(self):
        with self.assertRaises(ValidationError):
            validate_amount(None)


class CurrencyTests(unittest.TestCase):
    def test_normalises_case(self):
        self.assertEqual(validate_currency(" usd "), "USD")

    def test_rejects_unknown_or_empty(self):
        for bad in ["", "XXX", None, "US"]:
            with self.subTest(bad=bad), self.assertRaises(ValidationError):
                validate_currency(bad)


if __name__ == "__main__":
    unittest.main()
