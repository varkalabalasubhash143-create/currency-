import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

from currency_viewer.errors import RateFetchError
from currency_viewer.models import SOURCE_CACHED, SOURCE_LIVE, SOURCE_OFFLINE, SOURCE_STALE
from currency_viewer.rate_service import RateService


class Clock:
    def __init__(self):
        self.t = 1000.0

    def __call__(self):
        return self.t


class RateServiceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cache = Path(self.tmp.name) / "cache.json"
        self.clock = Clock()
        self.calls = 0
        self.fail = False

    def tearDown(self):
        self.tmp.cleanup()

    def fetcher(self, base):
        self.calls += 1
        if self.fail:
            raise RateFetchError("down")
        return {"USD": 1, "INR": 83.5}

    def svc(self):
        return RateService(self.cache, self.fetcher, ttl_seconds=60, clock=self.clock)

    def test_live_then_cached_within_ttl(self):
        s = self.svc()
        q1 = s.get_quote("USD")
        q2 = s.get_quote("USD")
        self.assertEqual((q1.source, q2.source), (SOURCE_LIVE, SOURCE_CACHED))
        self.assertEqual(self.calls, 1)
        self.assertEqual(q1.rates["INR"], Decimal("83.5"))

    def test_expired_cache_refetches(self):
        s = self.svc()
        s.get_quote("USD")
        self.clock.t += 61
        self.assertEqual(s.get_quote("USD").source, SOURCE_LIVE)
        self.assertEqual(self.calls, 2)

    def test_force_refresh_bypasses_cache(self):
        s = self.svc()
        s.get_quote("USD")
        s.get_quote("USD", force_refresh=True)
        self.assertEqual(self.calls, 2)

    def test_stale_cache_used_when_network_fails(self):
        s = self.svc()
        s.get_quote("USD")
        self.clock.t += 999
        self.fail = True
        self.assertEqual(s.get_quote("USD").source, SOURCE_STALE)

    def test_offline_table_when_nothing_available(self):
        self.fail = True
        q = self.svc().get_quote("INR")
        self.assertEqual(q.source, SOURCE_OFFLINE)
        self.assertEqual(q.rates["INR"], Decimal(1))
        self.assertGreater(q.rates["USD"], 0)

    def test_corrupt_cache_is_ignored(self):
        self.cache.write_text("{not json")
        self.assertEqual(self.svc().get_quote("USD").source, SOURCE_LIVE)


if __name__ == "__main__":
    unittest.main()
