import tempfile
import unittest
from datetime import datetime, timedelta
from decimal import Decimal
from pathlib import Path

from currency_viewer.errors import RateFetchError, ValidationError
from currency_viewer.rate_service import RateService
from currency_viewer.repository import ConversionRepository
from currency_viewer.service import ConverterService


class SnapshotRepoTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.repo = ConversionRepository(Path(self.tmp.name) / "t.db")
        self.t0 = datetime(2026, 1, 1, 12, 0, 0)

    def tearDown(self):
        self.tmp.cleanup()

    def test_store_and_read_series_oldest_first(self):
        self.repo.add_snapshots(self.t0, "USD", {"USD": Decimal(1), "INR": Decimal("80")})
        self.repo.add_snapshots(self.t0 + timedelta(hours=1), "USD", {"INR": Decimal("81")})
        series = self.repo.snapshot_series("USD", "INR")
        self.assertEqual([r for _, r in series], [Decimal("80"), Decimal("81")])
        self.assertEqual(self.repo.snapshot_series("USD", "USD"), [])  # base is never stored as target

    def test_throttle_skips_rapid_duplicates(self):
        self.assertEqual(self.repo.add_snapshots(self.t0, "USD", {"INR": Decimal(80)}), 1)
        self.assertEqual(self.repo.add_snapshots(self.t0 + timedelta(seconds=30), "USD", {"INR": Decimal(81)}), 0)
        self.assertEqual(len(self.repo.snapshot_series("USD", "INR")), 1)

    def test_limit_keeps_most_recent(self):
        for i in range(5):
            self.repo.add_snapshots(self.t0 + timedelta(hours=i), "USD", {"INR": Decimal(80 + i)})
        series = self.repo.snapshot_series("USD", "INR", limit=2)
        self.assertEqual([r for _, r in series], [Decimal(83), Decimal(84)])


class ServiceFeatureTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)
        self.fetch = lambda base: {"USD": 1, "INR": 80, "EUR": 0.5}
        self.repo = ConversionRepository(self.d / "t.db")
        self.svc = ConverterService(RateService(self.d / "c.json", self.fetch), self.repo)

    def tearDown(self):
        self.tmp.cleanup()

    def test_compare_all(self):
        quote, rows = self.svc.compare("USD", "10")
        by = {r.code: r for r in rows}
        self.assertEqual(by["INR"].converted, Decimal("800.00"))
        self.assertEqual(by["EUR"].converted, Decimal("5.00"))
        self.assertNotIn("USD", by)
        self.assertEqual([r.code for r in rows], sorted(by))
        self.assertEqual(quote.source, "Live")
        self.assertEqual(self.svc.history(), [])   # comparing is not a saved conversion

    def test_compare_validates(self):
        for args in [("USD", "0"), ("QQQ", "5"), ("USD", "abc")]:
            with self.subTest(args=args), self.assertRaises(ValidationError):
                self.svc.compare(*args)

    def test_live_fetch_records_snapshot_cached_does_not(self):
        self.svc.convert("USD", "INR", "1")
        self.svc.convert("USD", "INR", "1")          # served from cache
        self.assertEqual(len(self.svc.rate_history("USD", "INR")), 1)

    def test_offline_never_creates_snapshots(self):
        def down(_):
            raise RateFetchError("down")
        svc = ConverterService(RateService(self.d / "c2.json", down), self.repo)
        svc.convert("USD", "INR", "1")
        self.assertEqual(svc.rate_history("USD", "INR"), [])

    def test_rate_history_validates_codes(self):
        with self.assertRaises(ValidationError):
            self.svc.rate_history("USD", "???")


if __name__ == "__main__":
    unittest.main()
