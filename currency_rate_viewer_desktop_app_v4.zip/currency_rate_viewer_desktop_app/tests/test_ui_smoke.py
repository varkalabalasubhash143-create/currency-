"""Drives every handler of the Tkinter window against a stub toolkit.

This sandbox-friendly test proves the UI code is wired correctly to the service
(no NameError / AttributeError / wrong method names) on any machine, with or
without a display. It does not check pixel layout.
"""

import importlib
import sys
import tempfile
import types
import unittest
from pathlib import Path

from currency_viewer.rate_service import RateService
from currency_viewer.repository import ConversionRepository
from currency_viewer.service import ConverterService
from currency_viewer.settings import SettingsStore

NOOP = {"pack", "grid", "place", "bind", "title", "geometry", "minsize",
        "focus_set", "add", "heading", "column", "yview", "trace_add", "theme_use", "map",
        "columnconfigure", "create_line", "create_text", "create_rectangle", "create_oval",
        "delete", "insert", "state"}


class Widget:
    instances = []

    def __init__(self, *a, **k):
        self.val = k.get("value", "")
        self.children = []
        self.after_calls = []
        Widget.instances.append(self)

    def config(self, *_pos, **kw):
        self.cfg = {**getattr(self, "cfg", {}), **kw}

    configure = config

    def __getattr__(self, name):
        if name in NOOP:
            return lambda *a, **k: None
        raise AttributeError(name)

    def get(self):
        return self.val

    def set(self, v):
        self.val = v

    def after(self, ms, fn=None):
        self.after_calls.append(fn)

    def get_children(self):
        return ()

    def selection(self):
        return ("1",)

    def select(self):
        return ""

    def tab(self, *a):
        return self.__class__.current_tab

    def winfo_width(self):
        return 800

    def winfo_height(self):
        return 300

    current_tab = "Converter"


def build_fake_tk():
    tk = types.ModuleType("tkinter")
    ttk = types.ModuleType("tkinter.ttk")
    mb = types.ModuleType("tkinter.messagebox")
    fd = types.ModuleType("tkinter.filedialog")
    for n in ("Tk", "Canvas"):
        setattr(tk, n, type(n, (Widget,), {}))
    tk.StringVar = type("StringVar", (Widget,), {})
    for n in ("Frame", "Label", "Button", "Entry", "Combobox", "Notebook", "Treeview", "Scrollbar",
              "LabelFrame", "Style"):
        setattr(ttk, n, type(n, (Widget,), {}))
    mb.calls = []
    mb.showerror = lambda *a: mb.calls.append(("error", a))
    mb.showinfo = lambda *a: mb.calls.append(("info", a))
    mb.askyesno = lambda *a: True
    fd.asksaveasfilename = lambda **k: fd.path
    tk.ttk, tk.messagebox, tk.filedialog = ttk, mb, fd
    return {"tkinter": tk, "tkinter.ttk": ttk, "tkinter.messagebox": mb, "tkinter.filedialog": fd}


class UiSmokeTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.d = Path(self.tmp.name)
        self.saved = {k: sys.modules.get(k) for k in ("tkinter", "tkinter.ttk", "tkinter.messagebox",
                                                      "tkinter.filedialog")}
        self.fake = build_fake_tk()
        sys.modules.update(self.fake)
        for m in [m for m in sys.modules if m.startswith("currency_viewer.ui")]:
            del sys.modules[m]
        self.appmod = importlib.import_module("currency_viewer.ui.app")
        fetch = lambda base: {"USD": 1, "INR": 80, "EUR": 0.5}
        from datetime import datetime, timedelta
        from decimal import Decimal
        hist = lambda b, t, start, end: [(datetime(2026, 1, 1 + i, 12), Decimal(80 + i)) for i in range(5)]
        svc = ConverterService(RateService(self.d / "c.json", fetch, ttl_seconds=0),
                               ConversionRepository(self.d / "t.db"), hist)
        self.app = self.appmod.App(svc, SettingsStore(self.d / "s.json"))
        self.mb = self.fake["tkinter.messagebox"]

    def tearDown(self):
        for k, v in self.saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v
        for m in [m for m in sys.modules if m.startswith("currency_viewer.ui")]:
            del sys.modules[m]
        self.tmp.cleanup()

    def drain(self):
        for _ in range(200):
            if not self.app._queue.empty():
                break
            import time
            time.sleep(0.01)
        self.app._poll()

    def test_full_workflow(self):
        a = self.app
        a.cmb_from.set("USD"); a.cmb_to.set("INR"); a.ent_amt.set("5")
        a.convert(); self.drain()
        self.assertEqual(self.mb.calls, [])
        self.assertEqual(a.lbl_result.cfg["text"], "5 USD = 400.00 INR")
        self.assertEqual(a.lbl_result.cfg["style"], "good.Result.TLabel")
        self.assertIn("Source: Live", a.lbl_detail.cfg["text"])
        a.convert(force=True); self.drain()
        a.cmp_from.set("USD"); a.cmp_amt.set("2"); a.compare(); self.drain()
        a._swap(); a.toggle_favourite(); a._use_favourite() if a.cmb_fav.get() else None
        a.toggle_theme(); a.toggle_theme()
        for tab in ("Analytics", "Trends", "History", "Compare"):
            a.__class__.__mro__[1].current_tab = tab
            a._on_tab()
        a.refresh_history(); a.delete_selected(); a.clear_history()
        self.fake["tkinter.filedialog"].path = str(self.d / "out.csv")
        a.export_csv()
        self.assertTrue((self.d / "out.csv").exists())
        self.assertEqual([c[0] for c in self.mb.calls], ["info"])

    def test_alerts_and_history_workflow(self):
        a = self.app
        a.al_from.set("USD"); a.al_to.set("INR"); a.al_dir.set("above"); a.al_val.set("70")
        a.add_alert()
        self.assertEqual(len(a.svc.list_alerts()), 1)
        a.check_alerts(); self.drain()                      # live 80 >= 70 -> fires
        self.assertEqual([c[0] for c in self.mb.calls], ["info"])
        self.assertIn("USD/INR is 80", self.mb.calls[0][1][1])
        a.al_val.set("nonsense"); a.add_alert()
        self.assertEqual(self.mb.calls[-1][0], "error")
        a.tr_from.set("USD"); a.tr_to.set("INR")
        a.load_history_data(); self.drain()
        self.assertEqual(len(a.svc.rate_history("USD", "INR")), 6)   # 5 historical + 1 live snapshot
        a.rearm_alerts(); a.delete_alerts()
        a.__class__.__mro__[1].current_tab = "Alerts"
        a._on_tab()

    def test_conversion_alert_popup(self):
        a = self.app
        a.svc.add_alert("USD", "INR", "below", "90")
        a.cmb_from.set("USD"); a.cmb_to.set("INR"); a.ent_amt.set("1")
        a.convert(); self.drain()
        self.assertEqual([c[0] for c in self.mb.calls], ["info"])

    def test_invalid_input_shows_error_dialog(self):
        a = self.app
        a.ent_amt.set("-3")
        a.convert(); self.drain()
        self.assertEqual(self.mb.calls[0][0], "error")
        self.assertIn("greater than zero", self.mb.calls[0][1][1])


if __name__ == "__main__":
    unittest.main()
